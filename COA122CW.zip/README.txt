The system window is only to be closed from the quit button in the main menu, therfore, the exit button of the window is disabled.	
This system allows the user to return a list of books, and is able to checkout a list of books. 
Must have matplotlib installed before use, as this system uses graphs to represent books and their popularity.